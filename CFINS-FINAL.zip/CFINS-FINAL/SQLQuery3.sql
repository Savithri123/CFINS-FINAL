USE cfinsNw

SELECT * FROM NewRegister_details;

create table NewRegister_details(
	patient_id INT,
    patient_date date NOT NULL,
	patient_first_name varchar(100) NOT NULL,
	patient_address_ varchar(100),
	patient_city varchar(60),
	patient_district varchar(20),
	patient_telephone varchar(10),
	patient_age varchar(2),
	patient_sex varchar(1),
	patient_religion varchar(10),
	patient_race varchar(10),
	cause_of_amputation varchar(25),
	level_of_amputation varchar(25),
	leg  varchar(6),
	leg_description varchar(100)
		
	
	CONSTRAINT NewRegister_details_pk PRIMARY KEY(patient_id)
	);



